# PhishX

Copyright 2018 PhishX

![PHISHX](https://img.shields.io/badge/PhishX-v1.1-violet.svg?longCache=true&style=for-the-badge) ![PYTHON3.6](https://img.shields.io/badge/Python-3.6-green.svg?longCache=true&style=for-the-badge)

**PLAY WITH THE HUMAN ~MIND~**

**ONLY DOWNLOAD IT HERE, DO NOT TRUST OTHER PLACES.**


This is the official and only repository of the PhishX project.

Written by: Z-Hacker - Twitter: [@\_DEF9](https://twitter.com/_DEF9), GitHub: [@zanyarjamal](https://github.com/zanyarjamal)

DISCLAIMER: This is only for testing purposes and can only be used where strict consent has been given. Do not use this for illegal purposes, period.

Please read the LICENSE for the licensing of PhishX. 

[video demo](https://www.youtube.com/watch?v=C_Aa1yCPHF0)


# Features

* Generates a fake pages to capture passwords
* Adds Targets Info to the The Fake Page
* Sends SMS's using services like Facebook/Instagram/Google
* Sends SPOOFED emails with the SMTP you provide
* Uses NGROK to make the Fake pages Accessible world wide
* Grabs Victims IP Addresses and Does an IP lookup




### AVAILABLE PAGES

|Available Pages|Mobile Support|
|:---|:---:|
|Facebook|1|
|Google|1|
|GitHub|0|
|Twitter|1|
|Instagram|1|
|Steam|1|
|LinkedIn|0|
|Pinterest|1|
|Quora|1|





## Bugs and enhancements

For bug reports or enhancements, please open an [issue](https://github.com/weebsec/PhishX/issues) here.



## Tested on

* Kali linux 
* Parrot-Sec 



# Installation

**make sure your apt-get isn't broken before you run this**

**RUN THIS AS ROOT**
```bash
$ git clone https://github.com/WeebSec/PhishX.git
$ cd PhishX
$ chmod +x installer.sh
$ bash installer.sh
$ python3 PhishX.py
```
**Extra Info**
The [y/N] Questions are case sensitive so either you answer with "y" or with "N"
# SCREENSHOT
![SS](https://raw.githubusercontent.com/WeebSec/PhishX/master/img/Screenshot%20from%202018-09-28%2016-39-25.png)



